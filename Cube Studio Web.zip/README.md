![Cube Studio in Canva](images/CubeStudio.png)
# Cube Studio
Cube Studio is a 2D game engine that has a programing language called: CSScript that you need that archive like this: `.csscript` but you need that Hello World code like:
```
using CubeStudioEngine;
using System;

class HelloWorld main(); {
    printinConsole("Hello World!");
return;
}
```
# How it's created:
in Web, it's created in HTML and CSS.